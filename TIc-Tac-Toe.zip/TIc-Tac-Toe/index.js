const board = document.getElementById('board');
const message = document.getElementById('message');
const resetButton = document.getElementById('resetButton');
const player1NameInput = document.getElementById('player1Name');
const player2NameInput = document.getElementById('player2Name');
const player1WinsDisplay = document.getElementById('player1Wins');
const player2WinsDisplay = document.getElementById('player2Wins');

let currentPlayer = 'X';
let boardState = ['', '', '', '', '', '', '', '', ''];
let gameActive = true;
let player1Wins = 0;
let player2Wins = 0;

for (let i = 0; i < 9; i++) {
    const box = document.createElement('div');
    box.className = 'box';
    box.dataset.index = i;
    box.addEventListener('click', handleBoxClick);
    board.appendChild(box);
}

resetButton.addEventListener('click', resetBoard);

function handleBoxClick(event) {
    const index = event.target.dataset.index;

    if (boardState[index] === '' && gameActive) {
        boardState[index] = currentPlayer;
        event.target.textContent = currentPlayer;

        if (checkWin()) {
            updateWinCounter();
            message.textContent = `${getCurrentPlayerName()} wins!`;
            gameActive = false;
        } else if (boardState.every((box) => box !== '')) {
            message.textContent = "It's a draw!";
            gameActive = false;
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            message.textContent = `${getCurrentPlayerName()}'s turn`;
        }
    }
}

function checkWin() {
    const winPatterns = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6],
    ];

    return winPatterns.some((pattern) =>
        pattern.every((index) => boardState[index] === currentPlayer)
    );
}

function resetBoard() {
    boardState = ['', '', '', '', '', '', '', '', ''];
    document.querySelectorAll('.box').forEach((box) => {
        box.textContent = '';
    });

    currentPlayer = 'X';
    gameActive = true;
    message.textContent = `${getCurrentPlayerName()}'s turn`;
}

function getCurrentPlayerName() {
    let playerName = currentPlayer === 'X' ? player1NameInput.value : player2NameInput.value;
    return playerName.trim() !== '' ? playerName : `Player ${currentPlayer === 'X' ? '1' : '2'}`;
}

function updateWinCounter() {
    if (currentPlayer === 'X') {
        player1Wins++;
        player1WinsDisplay.textContent = player1Wins;
    } else {
        player2Wins++;
        player2WinsDisplay.textContent = player2Wins;
    }
}